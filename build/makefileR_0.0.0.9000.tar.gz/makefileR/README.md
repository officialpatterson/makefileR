# makefileR
Example showing how makefiles can be used as part of a R's build tooling.
