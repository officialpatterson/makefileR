library(testthat)
library(makefileR)

test_check("makefileR")
